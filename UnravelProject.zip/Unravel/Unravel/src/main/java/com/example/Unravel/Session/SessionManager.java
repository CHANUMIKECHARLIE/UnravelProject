package com.example.Unravel.Session;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SessionManager {

	// Thread-safe map
	private final Map<String, String> sessions = new ConcurrentHashMap<>();

	public String login(String userId) {

		try {
			// Atomically check and put if not present
			String sessionId = "SESSION_" + UUID.randomUUID().toString();
			String existingSession = sessions.putIfAbsent(userId, sessionId);

			if (existingSession != null) {
				return "User already logged in. Existing Session ID: " + existingSession;
			}

			return "Login successful. Session ID: " + sessionId;

		} catch (Exception e) {
			// Handle unexpected exceptions
			return "Login failed due to system error: " + e.getMessage();
		}
	}

	public String logout(String userId) {

		try {
			// remove returns null if key was not present
			String removedSession = sessions.remove(userId);
			if (removedSession == null) {
				return "User not logged in.";
			}
			return "Logout successful.";
		} catch (Exception e) {
			return "Logout failed due to error: " + e.getMessage();
		}
	}

	public String getSessionDetails(String userId) {

		try {
			String sessionId = sessions.get(userId);
			if (sessionId == null) {
				return "Session not found for user " + userId;
			}
			return "Session ID for user " + userId + ": " + sessionId;
		} catch (Exception e) {
			return "Error retrieving session for user " + userId + ": " + e.getMessage();
		}
	}

}
