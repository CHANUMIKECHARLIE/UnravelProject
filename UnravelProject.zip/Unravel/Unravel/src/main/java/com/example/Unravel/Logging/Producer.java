package com.example.Unravel.Logging;

import java.util.Random;

public class Producer implements Runnable {

	private final int taskCount;
	private final String producerName;
	private final LogProcessor processor;
	private final Random random = new Random();

	public Producer(LogProcessor processor, String producerName, int taskCount) {
		this.processor = processor;
		this.producerName = producerName;
		this.taskCount = taskCount;
	}

	@Override
	public void run() {

		Priority[] priorities = Priority.values();

		for (int i = 0; i < taskCount; i++) {

			Priority priority = priorities[random.nextInt(priorities.length)];
			String message = producerName + " Log-" + i + " [" + priority + "]";
			processor.produceLog(new LogTask(message, priority));

			try {
				Thread.sleep(10); // simulate work
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}
}
