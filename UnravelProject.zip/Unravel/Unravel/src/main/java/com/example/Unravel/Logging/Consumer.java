package com.example.Unravel.Logging;

//Consumer continuously processes logs
public class Consumer implements Runnable {

	private final LogProcessor processor;
	private final String consumerName;

	public Consumer(LogProcessor processor, String consumerName) {
		this.processor = processor;
		this.consumerName = consumerName;
	}

	@Override
	public void run() {

		try {
			while (true) {

				LogTask task = processor.consumeLog();
				System.out.println(consumerName + " consumed: " + task.getMessage());
				Thread.sleep(50); // simulate processing
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
}