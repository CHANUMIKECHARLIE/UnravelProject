package com.example.Unravel.Memory;

import java.util.LinkedHashMap;
import java.util.Map;

public class MemoryManager {

	private static final int MAX_ENTRIES = 100; // adjust based on load

	private static final Map<String, byte[]> sessionCache = new LinkedHashMap<>(MAX_ENTRIES, 0.75f, true) {
		@Override
		protected boolean removeEldestEntry(Map.Entry<String, byte[]> eldest) {
			return size() > MAX_ENTRIES;
		}
	};

	public static synchronized void addSessionData(String sessionId) {
		sessionCache.put(sessionId, new byte[10 * 1024 * 1024]); // 10 MB
		logMemoryUsage("Added session: " + sessionId);
	}

	public static synchronized void removeSessionData(String sessionId) {
		sessionCache.remove(sessionId);
		logMemoryUsage("Removed session: " + sessionId);
	}

	public static void logMemoryUsage(String message) {

		Runtime runtime = Runtime.getRuntime();
		long usedMem = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);
		long totalMem = runtime.totalMemory() / (1024 * 1024);
		System.out.println("[MemoryManager] " + message + " | Used: " + usedMem + "MB / " + totalMem + "MB");
	}
}
