package com.example.Unravel.Database;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.Timer;
import java.util.TimerTask;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zaxxer.hikari.HikariDataSource;

import jakarta.annotation.PostConstruct;

@Component
public class DatabaseManager {

	@Autowired
	private DataSource dataSource;

	private HikariDataSource hikariDataSource;

	@PostConstruct
	public void init() {

		if (dataSource instanceof HikariDataSource) {
			hikariDataSource = (HikariDataSource) dataSource;
			startMonitoring();
		}
	}

	public Connection getConnection() throws SQLException {

		Instant start = Instant.now();
		Connection conn = dataSource.getConnection();

		Instant end = Instant.now();
		long waitTimeMs = Duration.between(start, end).toMillis();

		if (waitTimeMs > 1000) {
			System.err.println("⚠️ Connection acquisition took too long: " + waitTimeMs + " ms");
		}

		return conn;
	}

	public void closeConnection(Connection connection) {

		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Custom HikariCP Monitoring
	private void startMonitoring() {

		Timer timer = new Timer(true);

		timer.scheduleAtFixedRate(new TimerTask() {

			@Override
			public void run() {

				int total = hikariDataSource.getHikariPoolMXBean().getTotalConnections();
				int active = hikariDataSource.getHikariPoolMXBean().getActiveConnections();

				int idle = hikariDataSource.getHikariPoolMXBean().getIdleConnections();
				int waiting = hikariDataSource.getHikariPoolMXBean().getThreadsAwaitingConnection();

				System.out.println("[HikariCP Monitor] Active: " + active + ", Idle: " + idle + ", Total: " + total
						+ ", Waiting: " + waiting);

				// Alert if all connections are in use
				if (waiting > 5) {
					System.err.println("🚨 High wait queue! Consider scaling DB or optimizing queries.");
				}

				// Detect underutilization
				if (active < 2 && idle > 5) {
					System.out.println("ℹ️ Pool underutilized. Consider tuning max/min pool size.");
				}
			}
		}, 0, 5000); // Check every 5 seconds
	}
}
