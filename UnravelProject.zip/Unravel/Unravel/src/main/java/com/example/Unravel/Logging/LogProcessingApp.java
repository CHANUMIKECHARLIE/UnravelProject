package com.example.Unravel.Logging;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LogProcessingApp {

	public static void main(String[] args) {

		LogProcessor processor = new LogProcessor();

		// Thread pool for producers and consumers
		ExecutorService executor = Executors.newFixedThreadPool(5);

		// 2 Producers
		executor.execute(new Producer(processor, "Producer-1", 50));
		executor.execute(new Producer(processor, "Producer-2", 50));

		// 3 Consumers
		executor.execute(new Consumer(processor, "Consumer-1"));
		executor.execute(new Consumer(processor, "Consumer-2"));
		executor.execute(new Consumer(processor, "Consumer-3"));
	}
}
