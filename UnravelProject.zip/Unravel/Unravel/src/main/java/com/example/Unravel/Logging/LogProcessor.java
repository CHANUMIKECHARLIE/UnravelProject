package com.example.Unravel.Logging;

import java.util.concurrent.PriorityBlockingQueue;

//Thread-safe processor using PriorityBlockingQueue
public class LogProcessor {

	private final PriorityBlockingQueue<LogTask> logQueue = new PriorityBlockingQueue<>();

	public void produceLog(LogTask logTask) {
		logQueue.put(logTask);
	}

	public LogTask consumeLog() throws InterruptedException {
		return logQueue.take();
	}
}
