package com.example.Unravel.Logging;

enum Priority {

	CRITICAL(3), HIGH(2), NORMAL(1);

	int level;

	Priority(int level) {
		this.level = level;
	}

	public int getLevel() {
		return level;
	}
}

//Task wrapper
class LogTask implements Comparable<LogTask> {

	private final String message;
	private final Priority priority;

	public LogTask(String message, Priority priority) {
		this.message = message;
		this.priority = priority;
	}

	public String getMessage() {
		return message;
	}

	public Priority getPriority() {
		return priority;
	}

	// Higher priority comes first
	@Override
	public int compareTo(LogTask o) {
		return Integer.compare(o.priority.getLevel(), this.priority.getLevel());
	}
}