package com.example.Unravel.Concurrency;

public class DeadlockSimulator {

	private final Object lock1 = new Object();
	private final Object lock2 = new Object();

	// Common method to acquire locks in consistent order
	public void executeWithOrderedLocks(Object firstLock, Object secondLock, String taskName) {

		synchronized (firstLock) {
			synchronized (secondLock) {
				System.out.println(taskName + ": Acquired both locks");
			}
		}
	}

	public void method1() {
		executeWithOrderedLocks(lock1, lock2, "Method1");
	}

	public void method2() {
		executeWithOrderedLocks(lock1, lock2, "Method2");
	}

	public static void main(String[] args) {

		DeadlockSimulator simulator = new DeadlockSimulator();

		Thread t1 = new Thread(simulator::method1);
		Thread t2 = new Thread(simulator::method2);

		t1.start();
		t2.start();
	}
}
